package com.example.android.testapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;



public class ActivityA extends Activity {

    public static int counter;
    private String mCounter;
    private String mActivityName;
    private TextView myView;

    @SuppressLint("SetTextI18n")
    @Override
    public void onCreate(Bundle savedInstanceState) {

        if( savedInstanceState != null)
        {
            counter = savedInstanceState.getInt("MyInt");
        }
        else
        {
            counter = 0;
        }
        super.onCreate(savedInstanceState);
            mCounter = Integer.toString(counter);
            myView.setText("Thread Counter : - " + mCounter);
        }



    @Override
    protected void onStart() {
        super.onStart();

    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onRestart() {
        super.onRestart();
        counter++;
        mCounter = Integer.toString(counter);
        myView.setText("Thread Counter : - " + mCounter);
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onPause() {
        super.onPause();
        
    }

    @Override
    protected void onStop() {
        super.onStop();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public void startDialog(View v) {
        Intent intent = new Intent(ActivityA.this, DialogActivity.class);
        startActivity(intent);
    }

    public void startActivityB(View v) {
        Intent intent = new Intent(ActivityA.this, ActivityB.class);
        startActivity(intent);
    }

    public void finishActivityA(View v) {
        ActivityA.this.finish();
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putInt("MyInt", counter);
        super.onSaveInstanceState(savedInstanceState);
    }



}
